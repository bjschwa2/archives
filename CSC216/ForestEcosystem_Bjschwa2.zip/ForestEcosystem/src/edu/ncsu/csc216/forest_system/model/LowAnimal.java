/**
 * 
 */
package edu.ncsu.csc216.forest_system.model;

import java.awt.Color;

/**
 * Provides the functionality for the low animals in the ecosystem.
 * 
 * @author Bradley Schwarz
 * 
 */
public class LowAnimal extends Organism {

	// Variables used to make low animals act
	private final static Color COLOR = Color.green;
	private final static int FOOD_CHAIN_RANK = 200;
	private final static int BREED_TIME = 2;
	private final static int LIFE_SPAN = 10;

	// the age of the animal
	private int age;

	/**
	 * Constructor -- constructs the low animals.
	 * 
	 * @param symbol
	 *            the symbol that defines the organism
	 */
	public LowAnimal(char symbol) {
		super(symbol, COLOR);
		this.age = 0;

	}

	/**
	 * Provides the actions for the low animals.
	 * 
	 * @param where
	 *            the current location
	 * @param grid
	 *            the grid the cell is on
	 */
	public void act(Cell where, Grid grid) {
		int direction = getDirection();

		// finds the nearest empty cell
		Cell empty = grid.findFirstEmptyNeighbor(where, direction);

		// checks if the animals can act
		if (canAct()) {

			// Checks if the organism can breed.
			if (pastBreedTime(getTimeSinceLastBreed())) {
				if (breed(where, grid)) {

					grid.add(makeNewBaby(), empty);

				}
				// Checks if the organism can move
			} else if (empty != where) {
				incrementTimeSinceLastBreed();
				move(where, grid);
				// Does nothing
			} else {
				incrementTimeSinceLastBreed();

			}
			// Increments the age of the organism
			age++;
			// checks if the Organism is too old
			if (age >= LIFE_SPAN) {
				die();
			}
		}

		// Disables the organism
		disable();
	}

	/**
	 * Creates a new baby of a low Animal.
	 * 
	 * @return newAnimal the new baby
	 */
	public Item makeNewBaby() {

		Item newAnimal = new LowAnimal(getSymbol());

		return newAnimal;
	}

	/**
	 * Checks to see if the animal can breed.
	 * 
	 * @param timeSinceLastBreed
	 *            the last the animal bred
	 * @return if the organism can breed
	 */
	public boolean pastBreedTime(int timeSinceLastBreed) {

		return BREED_TIME <= timeSinceLastBreed;
	}

	/**
	 * Getter -- returns the food chain rank for low animal.
	 * 
	 * @return FOOD_CHAIN_RANK the low animal food chain rank
	 */
	public int getFoodChainRank() {

		return FOOD_CHAIN_RANK;
	}

}
