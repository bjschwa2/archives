/**
 * 
 */
package edu.ncsu.csc216.forest_system.model;

/**
 * The Cell object that makes up the Grid
 * 
 * @author Bradley Schwarz
 *
 */
public class Cell {
	
	// the row and column number
	private int row;
	private int column;
	
	/**
	 * Constructor -- Constructs the Cell
	 * 
	 * @param row the row number
	 * @param column the column number
	 */
	public Cell(int row, int column){
		 
		// Assigns values to row and column
		this.row = row;
		this.column = column;
		
	}
	
	/**
	 * Returns the row of the cell
	 * 
	 * @return the cell row
	 */
	public int getRow(){
		
		return row;
		
	}
	
	/**
	 * Returns the Column of the cell
	 * 
	 * @return the cell column
	 */
	public int getCol(){
		
		return column;
	}

}
