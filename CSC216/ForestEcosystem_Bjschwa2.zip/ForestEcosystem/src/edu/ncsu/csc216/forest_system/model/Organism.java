/**
 * 
 */
package edu.ncsu.csc216.forest_system.model;

import java.awt.Color;
import java.util.Random;

/**
 * Creates and provides the actions to the Organisms.
 * 
 * @author Bradley Schwarz
 */
public abstract class Organism implements Item {

	// private values to use in the methods
	private int timeSinceLastMeal;
	private int timeSinceLastBreed;
	private boolean canActThisStep;
	private char symbol;
	private boolean alive;
	private Color color;

	// created the random seed
	private static int seed = 500;
	private static Random randomGenerator = new Random(seed);

	/**
	 * Constructor -- Creates the organism using the symbol and color
	 * 
	 * @param symbol
	 *            char of organism
	 * @param color
	 *            color of organism
	 */
	public Organism(char symbol, Color color) {

		// Initializing the symbol and color
		this.symbol = symbol;
		this.color = color;
		this.alive = true;
	}

	/**
	 * sets the random seed
	 * 
	 * @param seed
	 *            the seed value
	 */
	public static void setRandomSeed(int seed) {

		randomGenerator = new Random(seed);

	}

	/**
	 * Checks if the organism is Alive
	 * 
	 * @return if the organism is alive
	 */
	public boolean isAlive() {

		return alive;

	}

	/**
	 * Causes the Organism to die.
	 * 
	 */
	public void die() {
		alive = false;

	}

	/**
	 * Checks if the Organism can act.
	 * 
	 * @return if the organism can act
	 */
	public boolean canAct() {
		return canActThisStep;

	}

	/**
	 * Allows the organism to act.
	 * 
	 */
	public void enable() {
		canActThisStep = true;

	}

	/**
	 * Makes the organism unable to act.
	 * 
	 */
	public void disable() {
		canActThisStep = false;

	}

	/**
	 * Checks when the organism last bred.
	 * 
	 * @return the time since the organism bred.
	 */
	public int getTimeSinceLastBreed() {
		return timeSinceLastBreed;

	}

	/**
	 * Checks with the organism last Ate.
	 * 
	 * @return time since the organism ate.
	 */
	public int getTimeSinceLastMeal() {
		return timeSinceLastMeal;

	}

	/**
	 * Adds one to the time since the organism ate.
	 */
	public void incrementTimeSinceLastMeal() {
		timeSinceLastMeal++;

	}

	/**
	 * Adds one to the time the organism last breed
	 */
	public void incrementTimeSinceLastBreed() {
		timeSinceLastBreed++;

	}

	/**
	 * get the randomized value
	 * 
	 * @return the random generator value
	 */
	protected int getDirection() {
		return randomGenerator.nextInt(4);
	}

	/**
	 * Checks if the organism can breed
	 * 
	 * @param where
	 *            location of organism
	 * @param grid
	 *            Grid the organism is on
	 * @return if the organism can breed
	 */
	public boolean breed(Cell where, Grid grid) {
		int direction = getDirection();
		boolean breed = false;

		Cell empty = grid.findFirstEmptyNeighbor(where, direction);

		if (empty != where) {
			breed = true;

			// resets when the organism last breed to 0.
			timeSinceLastBreed = 0;

		}

		return breed;

	}

	/**
	 * moves an organism to the first empty neighbor
	 * 
	 * @param where
	 *            current location
	 * @param grid
	 *            grid organism is on
	 */
	public void move(Cell where, Grid grid) {
		int direction = getDirection();
		Cell empty = grid.findFirstEmptyNeighbor(where, direction);
		Item item = grid.getItemAt(where);

		if (empty != where) {

			grid.add(item, empty);

			grid.remove(where);
		}

	}

	/**
	 * Checks if the Animal can eat.
	 * 
	 * @param where
	 *            current location
	 * @param grid
	 *            the grid the organism is on
	 * @return if the organism can eat
	 */
	public boolean eat(Cell where, Grid grid) {
		int direction = getDirection();

		Cell prey = findAnimal(where, direction, grid);

		if (where == prey) {
			return false;
		} else {

			Item predator = grid.getItemAt(where);

			grid.remove(prey);

			grid.add(predator, prey);

			grid.remove(where);

			return true;
		}

	}

	/**
	 * Finds an adjacent animal with a lower food chain rank
	 * 
	 * @param position
	 *            current location
	 * @param startDirection
	 *            the direction the animal starts looking
	 * @param grid
	 *            grid the animal is on
	 * @return cell containing animal that can be eaten
	 */
	private Cell findAnimal(Cell position, int startDirection, Grid grid) {

		int initialDirection = startDirection;

		if (initialDirection == 0) {
			if (!grid.isEmpty(grid.dueWest(position))) {

				if (getRank(position, grid) > getRank(grid.dueWest(position),
						grid)) {
					return grid.dueWest(position);
				}

			} else if (!grid.isEmpty(grid.dueNorth(position))) {
				if (getRank(position, grid) > getRank(grid.dueNorth(position),
						grid)) {
					return grid.dueNorth(position);
				}

			} else if (!grid.isEmpty(grid.dueEast(position))) {
				if (getRank(position, grid) > getRank(grid.dueEast(position),
						grid)) {
					return grid.dueEast(position);
				}

			} else if (!grid.isEmpty(grid.dueSouth(position))) {
				if (getRank(position, grid) > getRank(grid.dueSouth(position),
						grid)) {
					return grid.dueSouth(position);
				}

			} else {
				return position;

			}

		} else if (initialDirection == 1) {
			if (!grid.isEmpty(grid.dueNorth(position))) {
				if (getRank(position, grid) > getRank(grid.dueNorth(position),
						grid)) {
					return grid.dueNorth(position);
				}

			} else if (!grid.isEmpty(grid.dueEast(position))) {
				if (getRank(position, grid) > getRank(grid.dueEast(position),
						grid)) {
					return grid.dueEast(position);
				}

			} else if (!grid.isEmpty(grid.dueSouth(position))) {
				if (getRank(position, grid) > getRank(grid.dueSouth(position),
						grid)) {
					return grid.dueSouth(position);
				}
			} else if (!grid.isEmpty(grid.dueWest(position))) {
				if (getRank(position, grid) > getRank(grid.dueWest(position),
						grid)) {
					return grid.dueWest(position);
				}

			} else {
				return position;

			}

		} else if (initialDirection == 2) {
			if (!grid.isEmpty(grid.dueEast(position))) {
				if (getRank(position, grid) > getRank(grid.dueEast(position),
						grid)) {
					return grid.dueEast(position);
				}

			} else if (!grid.isEmpty(grid.dueSouth(position))) {
				if (getRank(position, grid) > getRank(grid.dueSouth(position),
						grid)) {
					return grid.dueSouth(position);
				}

			} else if (!grid.isEmpty(grid.dueWest(position))) {
				if (getRank(position, grid) > getRank(grid.dueWest(position),
						grid)) {
					return grid.dueWest(position);
				}

			} else if (!grid.isEmpty(grid.dueNorth(position))) {
				if (getRank(position, grid) > getRank(grid.dueNorth(position),
						grid)) {
					return grid.dueNorth(position);
				}

			} else {
				return position;

			}

		} else if (initialDirection == 3) {
			if (!grid.isEmpty(grid.dueSouth(position))) {
				if (getRank(position, grid) > getRank(grid.dueSouth(position),
						grid)) {
					return grid.dueSouth(position);
				}

			} else if (!grid.isEmpty(grid.dueWest(position))) {
				if (getRank(position, grid) > getRank(grid.dueWest(position),
						grid)) {
					return grid.dueWest(position);
				}

			} else if (!grid.isEmpty(grid.dueNorth(position))) {
				if (getRank(position, grid) > getRank(grid.dueNorth(position),
						grid)) {
					return grid.dueNorth(position);
				}

			} else if (!grid.isEmpty(grid.dueEast(position))) {
				if (getRank(position, grid) > getRank(grid.dueEast(position),
						grid)) {
					return grid.dueEast(position);
				}
			} else {
				return position;

			}

		}
		return position;

	}

	/**
	 * Gets the rank of the animal in a cell
	 * 
	 * @param position
	 *            location of animal
	 * @param grid
	 *            the grid the animal is on
	 * @return the rank of the animal
	 */
	private int getRank(Cell position, Grid grid) {

		Organism organism = (Organism) grid.getItemAt(position);
		int rank = organism.getFoodChainRank();
		return rank;
	}

	/**
	 * Getter -- gets the symbol of an animal.
	 * 
	 * @return the symbol
	 */
	public char getSymbol() {
		return symbol;

	}

	/**
	 * Getter -- gets the color of an animal.
	 * 
	 * @return the color
	 */
	public Color getColor() {
		return color;

	}

	/**
	 * Getter -- gets the food chain rank of an animal.
	 * 
	 * @return the food chain rank
	 */
	public abstract int getFoodChainRank();

	/**
	 * Abstract method to create a baby.
	 * 
	 * @return the baby
	 */
	public abstract Item makeNewBaby();

	/**
	 * Abstract method to make the organism act.
	 * 
	 * @param where
	 *            current location
	 * @param grid
	 *            the rgid the cell is on
	 */
	public abstract void act(Cell where, Grid grid);

	/**
	 * Abstract method that checks for the past breed time.
	 * 
	 * @param age
	 *            the age of the organism
	 * @return if it can breed
	 */
	public abstract boolean pastBreedTime(int age);

}
