/**
 * 
 */
package edu.ncsu.csc216.forest_system.model;

/**
 * 
 * Hold the values for each Item relating to the Grid of cells.
 * 
 * @author Bradley Schwarz
 * 
 */
public class Ecosystem implements Grid {

	// Values for the max rows and columns
	private int maxRows;
	private int maxCols;

	// Initalizing the map of Items
	private Item[][] map;

	/**
	 * Constructor -- contructs the ecosystem.
	 * 
	 * @param maxRows
	 *            the max rows
	 * @param maxCols
	 *            the max columns
	 */
	public Ecosystem(int maxRows, int maxCols) {

		// Assigns the values for the rows and columns
		this.maxRows = maxRows;
		this.maxCols = maxCols;

		// creates the map
		map = new Item[maxRows][maxCols];

	}

	/**
	 * 
	 * Returns the value of map to SimpleSimulator
	 * 
	 * @return map the 2D array of items
	 */
	public Item[][] snapshot() {

		return map;

	}

	/**
	 * returns the Item at a specific cell location
	 * 
	 * @param location
	 *            the cell's location
	 * @return space the item at the cell
	 */
	public Item getItemAt(Cell location) {

		Item space = map[location.getRow()][location.getCol()];

		return space;

	}

	/**
	 * remove an Item at a call location
	 * 
	 * @param location
	 *            the cell's location
	 */
	public void remove(Cell location) {

		map[location.getRow()][location.getCol()] = null;

	}

	/**
	 * Checks if a Cell has an item in it
	 * 
	 * @param location
	 *            the cell's location
	 * @return if the cell is empty
	 */

	public boolean isEmpty(Cell location) {

		Item spaceItem = getItemAt(location);

		return spaceItem == null;
	}

	/**
	 * Adds an Item to a specific cell
	 * 
	 * @param item
	 *            the item to be added
	 * @param location
	 *            the location to be added to
	 */

	public void add(Item item, Cell location) {
		

		map[location.getRow()][location.getCol()] = item;

	}

	/**
	 * returns the first empty neighbor of a cell
	 * 
	 * @param position
	 *            the initial cell location
	 * @param startDirection
	 *            the direction the animal tries first
	 * @return the first empty neighboring cell
	 */

	public Cell findFirstEmptyNeighbor(Cell position, int startDirection) {

		int initialDirection = startDirection;

		if (initialDirection == 0) {
			if (isEmpty(dueWest(position))) {
				return dueWest(position);

			} else if (isEmpty(dueNorth(position))) {
				return dueNorth(position);

			} else if (isEmpty(dueEast(position))) {
				return dueEast(position);

			} else if (isEmpty(dueSouth(position))) {
				return dueSouth(position);

			} else {
				return position;

			}

		} else if (initialDirection == 1) {
			if (isEmpty(dueNorth(position))) {
				return dueNorth(position);

			} else if (isEmpty(dueEast(position))) {
				return dueEast(position);

			} else if (isEmpty(dueSouth(position))) {
				return dueSouth(position);

			} else if (isEmpty(dueWest(position))) {
				return dueWest(position);

			} else {
				return position;

			}

		} else if (initialDirection == 2) {
			if (isEmpty(dueEast(position))) {
				return dueEast(position);

			} else if (isEmpty(dueSouth(position))) {
				return dueSouth(position);

			} else if (isEmpty(dueWest(position))) {
				return dueWest(position);

			} else if (isEmpty(dueNorth(position))) {
				return dueNorth(position);

			} else {
				return position;

			}

		} else if (initialDirection == 3) {
			if (isEmpty(dueSouth(position))) {
				return dueSouth(position);

			} else if (isEmpty(dueWest(position))) {
				return dueWest(position);

			} else if (isEmpty(dueNorth(position))) {
				return dueNorth(position);

			} else if (isEmpty(dueEast(position))) {
				return dueEast(position);
			} else {
				return position;

			}

		}
		return position;

	}

	/**
	 * finds the cell north of x
	 * 
	 * @param x
	 *            the cell
	 * @return north The north cell
	 */

	public Cell dueNorth(Cell x) {

		int northRow = x.getRow();
		int northCol = x.getCol();
		Cell north = null;

		if (northRow == 0) {
			north = new Cell(maxCols - 1, northCol);
		} else {
			north = new Cell(northRow - 1, northCol);
		}

		return north;
	}

	/**
	 * finds the cell south of x
	 * 
	 * @param x
	 *            the cell
	 * @return south The south cell
	 */

	public Cell dueSouth(Cell x) {

		int southRow = x.getRow();
		int southCol = x.getCol();
		Cell south = null;

		if (southRow == maxRows - 1) {
			south = new Cell(0, southCol);
		} else {
			south = new Cell(southRow + 1, southCol);
		}

		return south;
	}

	/**
	 * finds the cell West of x
	 * 
	 * @param x
	 *            the cell
	 * @return west The west cell
	 */

	public Cell dueWest(Cell x) {

		int westRow = x.getRow();
		int westCol = x.getCol();
		Cell west = null;

		if (westCol == 0) {
			west = new Cell(westRow, maxCols - 1);
		} else {
			west = new Cell(westRow, westCol - 1);
		}

		return west;
	}

	/**
	 * finds the cell east of x
	 * 
	 * @param x
	 *            the cell
	 * @return east The east cell
	 */
	public Cell dueEast(Cell x) {

		int eastRow = x.getRow();
		int eastCol = x.getCol();
		Cell east = null;

		if (eastCol == maxRows - 1) {
			east = new Cell(eastRow, 0);
		} else {
			east = new Cell(eastRow, eastCol + 1);
		}

		return east;
	}

}
