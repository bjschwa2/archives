/**
 * 
 */
package edu.ncsu.csc216.forest_system.model;

import java.awt.Color;

/**
 * Provides the functionality for the middle animals in the ecosystem.
 * 
 * @author Bradley Schwarz
 * 
 */
public class MiddleAnimal extends Organism {

	// variables used to provide actions for the organism
	private final static Color COLOR = Color.orange;
	private final static int FOOD_CHAIN_RANK = 400;
	private final static int BREED_TIME = 7;
	private final static int STARVE_TIME = 5;

	/**
	 * Constructor -- creates the middle animal
	 * 
	 * @param symbol
	 *            the symbol for the middle animal
	 */
	public MiddleAnimal(char symbol) {
		super(symbol, COLOR);

	}

	/**
	 * Provides the actions for the middle animal type.
	 * 
	 * @param where
	 *            the current location
	 * @param grid
	 *            the grid the cell is on
	 */
	public void act(Cell where, Grid grid) {
		int direction = getDirection();
		Cell empty = grid.findFirstEmptyNeighbor(where, direction);

		// Checks if the animal can act
		if (canAct()) {

			// Checks if the animal can breed
			if (pastBreedTime(getTimeSinceLastBreed())) {
				if (breed(where, grid)) {

					// Adds a baby to the empty cell
					grid.add(makeNewBaby(), empty);
				}
				// Increments meal time
				incrementTimeSinceLastMeal();

				// Checks if the animal can eat
			} else if (eat(where, grid)) {
				incrementTimeSinceLastBreed();

				// Checks if the animal is surrounded
			} else if (where != empty) {

				incrementTimeSinceLastBreed();

				// Moves animal
				move(where, grid);
				incrementTimeSinceLastMeal();

				// Animal does nothing
			} else {
				
				incrementTimeSinceLastMeal();
				incrementTimeSinceLastBreed();
			}
			// checks if animal starves
			if (getTimeSinceLastMeal() >= STARVE_TIME) {
				
				die();
			}

		}
		// disables the animal
		disable();

	}

	/**
	 * Creates a baby and returns it.
	 * 
	 * @return newAnimal the new baby
	 */
	public Item makeNewBaby() {

		Item newAnimal = new MiddleAnimal(getSymbol());

		return newAnimal;

	}

	/**
	 * Checks if the animal can breed.
	 * 
	 * @param timeSinceLastBreed
	 *            the time since the animal breed
	 * @return if the animal can breed
	 */
	public boolean pastBreedTime(int timeSinceLastBreed) {
		return BREED_TIME <= timeSinceLastBreed;
	}

	/**
	 * Getter -- finds the animals food chain rank.
	 * 
	 * @return the animals food chain rank
	 */
	public int getFoodChainRank() {

		return FOOD_CHAIN_RANK;
	}

}
