/**
 * 
 */
package edu.ncsu.csc216.forest_system.model;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * The front end of the model for Forest Ecosystem.
 * 
 * @author Bradley Schwarz
 * 
 */
public class SimpleSimulator {

	// the size and threshold of the initial 2D array
	private final static int SIZE = 20;
	private final static int THRESHHOLD = 20;

	// Value for empty used for the text file
	// private final static char EMPTY = '.';

	// the private values of objects used in the class
	private String[] names;
	int numberOfNames;
	private char[] symbol;
	private Grid simpleSystem;

	// values I created to help scanning
	char letter;
	int animalClass;
	Organism newAnimal;

	/**
	 * The constructor -- creates a 2D array of objects based on file
	 * 
	 * @param filename
	 *            the name of the file used to create the 2D array
	 */
	public SimpleSimulator(String filename) {

		// Initial file scanner
		Scanner scanTxt = null;

		// checks if file exists
		try {
			scanTxt = new Scanner(new File(filename));

		} catch (FileNotFoundException e) {

			throw new IllegalArgumentException("File does not exist");
		}

		// Scans the next line
		String nextLine = scanTxt.nextLine();

		// Makes sure the first character is an Integer
		try {
			numberOfNames = Integer.parseInt(nextLine);

		} catch (IllegalArgumentException e) {

			throw new IllegalArgumentException(
					"File does not meet requirements.");

		}
		// Test the files rows and Columns
		testCol(filename);
		testRow(filename);

		// Assigns the int value to numberOfNames
		numberOfNames = Integer.parseInt(nextLine);

		nextLine = scanTxt.nextLine();

		// creates the names and symbol arrays
		this.names = new String[numberOfNames];
		this.symbol = new char[numberOfNames];

		// creates and increment value
		int orgScan = 0;

		String nameSpace = "";

		// scans the file and fills the Name and symbol array
		while (orgScan < numberOfNames) {
			Scanner scanFile = new Scanner(nextLine);
			this.symbol[orgScan] = nextLine.charAt(0);
			scanFile.next();
			while (scanFile.hasNext()) {
				nameSpace += scanFile.next();
				if (scanFile.hasNext()) {
					nameSpace += " ";
				}
			}
			this.names[orgScan] = nameSpace;
			orgScan++;
			nextLine = scanTxt.nextLine();
			nameSpace = "";
		}
		char[][] array = new char[SIZE][SIZE];

		// Creates the array
		while (scanTxt.hasNextLine()) {
			for (int i = 0; i < SIZE; i++) {
				for (int j = 0; j < SIZE; j++) {
					array[i][j] = nextLine.charAt(j);

				}
				if (scanTxt.hasNextLine()) {
					nextLine = scanTxt.nextLine();
				}
			}

		}

		// Fills the array with Organisms
		simpleSystem = new Ecosystem(SIZE, THRESHHOLD);
		for (int i = 0; i < SIZE; i++) {
			for (int j = 0; j < SIZE; j++) {
				letter = array[i][j];

				// Checks what time of organism to fill
				Cell animalCell = new Cell(i, j);
				animalClass = animalChar(letter);
				if (animalClass == 'H') {
					newAnimal = new HighAnimal(letter);
					simpleSystem.add(newAnimal, animalCell);
				} else if (animalClass == 'M') {
					newAnimal = new MiddleAnimal(letter);
					simpleSystem.add(newAnimal, animalCell);
				} else if (animalClass == 'L') {
					newAnimal = new LowAnimal(letter);
					simpleSystem.add(newAnimal, animalCell);
				} else if (animalClass == 'B') {
					newAnimal = null;
					simpleSystem.add(null, animalCell);
				}

			}
		}

	}

	/**
	 * Returns a letter based of the symbol of the animal.
	 * 
	 * @param letter
	 *            the character to return
	 * @return the character being returned
	 */
	private char animalChar(char letter) {
		if (letter == this.symbol[0]) {
			return 'H';
		}
		if (letter == this.symbol[this.symbol.length - 1]) {
			return 'L';
		}
		for (int i = 1; i < this.symbol.length - 1; i++) {
			if (letter == this.symbol[i]) {
				return 'M';
			}
		}

		return 'B';
	}

	/**
	 * Steps though the array to check for dead animals and make alive ones act.
	 * 
	 */
	public void step() {

		// Steps through the array

		for (int k = 0; k < SIZE; k++) {
			for (int j = 0; j < SIZE; j++) {

				Cell cell = new Cell(j, k);

				// Checks if cell is Empty
				if (!simpleSystem.isEmpty(cell)) {
					// enables animal
					simpleSystem.getItemAt(cell).enable();
					// checks if animals can act
					// Removes animals is dead
					if (((Organism) simpleSystem.getItemAt(cell)).canAct()
							&& !simpleSystem.getItemAt(cell).isAlive()) {

						simpleSystem.remove(cell);
					}

				}
			}
		}

		for (int a = 0; a < SIZE; a++) {
			for (int b = 0; b < SIZE; b++) {

				Cell cell = new Cell(a, b);

				if (simpleSystem.getItemAt(cell) != null) {

					// makes animals act
					simpleSystem.getItemAt(cell).act(cell, simpleSystem);

				}

			}

		}
	}

	/**
	 * returns a snapshot of the Grid of animals
	 * 
	 * @return the 2D array of animals
	 */
	public Item[][] snapshot() {

		Item[][] creature = simpleSystem.snapshot();

		return creature;

	}

	/**
	 * returns the array of names
	 * 
	 * @return array of names
	 */
	public String[] displayItemNames() {

		return names;

	}

	/**
	 * test the amount of columns
	 * 
	 * @param filename
	 *            the file being scanned
	 */
	private void testCol(String filename) {
		Scanner scanFile = null;
		try {
			scanFile = new Scanner(new File(filename));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		int numberOfAnimals = scanFile.nextInt();
		int skipFirstRows = 0;
		while (skipFirstRows < numberOfAnimals) {
			scanFile.nextLine();
			skipFirstRows++;
		}
		int linesScanned = 0;
		while (scanFile.hasNextLine()) {
			scanFile.nextLine();
			linesScanned++;
		}
		if (linesScanned > SIZE + 1) {
			throw new IllegalArgumentException(
					"File does not meet requirements.");
		}

	}

	/**
	 * test the amount of rows
	 * 
	 * @param filename
	 *            the file being used
	 */
	private void testRow(String filename) {

		Scanner scanFile = null;
		try {
			scanFile = new Scanner(new File(filename));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		int numberOfAnimals = scanFile.nextInt();
		int skipFirstRows = 0;
		while (skipFirstRows < numberOfAnimals) {
			scanFile.nextLine();
			skipFirstRows++;
		}
		String line;
		while (scanFile.hasNextLine()) {
			line = scanFile.nextLine();
			if (line.length() > SIZE) {
				throw new IllegalArgumentException(
						"File does not meet requirements.");
			}
		}
	}
}
