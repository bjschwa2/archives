/**
 * 
 */
package edu.ncsu.csc216.forest_system.model;

import java.awt.Color;

/**
 * Provides the functionality for the high animals
 * 
 * @author Bradley Schwarz
 */
public class HighAnimal extends Organism {

	// Variables used to make the organism act
	private final static Color COLOR = Color.red;
	private final static int FOOD_CHAIN_RANK = 500;
	private final static int BREED_TIME = 15;
	private final static int STARVE_TIME = 4;

	/**
	 * Constructor -- makes the high animal.
	 * 
	 * @param symbol
	 *            the symbol of the high animal
	 */
	public HighAnimal(char symbol) {
		super(symbol, COLOR);

	}

	/**
	 * Provides the actions for the high animal.
	 * 
	 * @param where
	 *            location the animal is
	 * @param grid
	 *            the grid the cell is on
	 */
	public void act(Cell where, Grid grid) {
		int direction = getDirection();
		Cell empty = grid.findFirstEmptyNeighbor(where, direction);

		// Checks if the animal can act
		if (canAct()) {
			// Animal eats if it can
			if (eat(where, grid) ) {

				// Increments the breed time
				incrementTimeSinceLastBreed();

				// Checks if the animal can breed
			} else if (pastBreedTime(getTimeSinceLastBreed())) {
				if (breed(where, grid)) {

					grid.add(makeNewBaby(), empty);
				}
				incrementTimeSinceLastMeal();

				// Checks if the animal can move
			} else if (where != empty) {

				incrementTimeSinceLastBreed();

				// moves the animal
				move(where, grid);
				incrementTimeSinceLastMeal();

				// animal does nothing
			} else {

				incrementTimeSinceLastBreed();
				incrementTimeSinceLastMeal();
			}
			// Checks if the animal dies of starvation
			if (getTimeSinceLastMeal() >= STARVE_TIME) {
				die();
			}

		}
		// disables the animal
		disable();

	}

	/**
	 * Makes a new baby of type high animal.
	 * 
	 * @return newAnimal the new baby
	 */
	public Item makeNewBaby() {

		Item newAnimal = new HighAnimal(getSymbol());

		return newAnimal;
	}

	/**
	 * Getter -- gets the food chain rank of the high organism
	 * 
	 * @return FOOD_CHAIN_RANK the food chain rank
	 */
	public int getFoodChainRank() {

		return FOOD_CHAIN_RANK;
	}

	/**
	 * Checks if the animal is able to breed
	 * 
	 * @param timeSinceLastBreed
	 *            the time since the animal breed
	 * @return if the organism can breed
	 */
	public boolean pastBreedTime(int timeSinceLastBreed) {

		return BREED_TIME <= timeSinceLastBreed;
	}

}
