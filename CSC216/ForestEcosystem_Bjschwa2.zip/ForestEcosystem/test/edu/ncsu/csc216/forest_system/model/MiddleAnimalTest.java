/**
 * 
 */
package edu.ncsu.csc216.forest_system.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * Test case for MiddleAnimal.
 * 
 * @author Bradley Schwarz
 * 
 */
public class MiddleAnimalTest {

	private Cell cellTest1;
	private Cell cellTest2;
	private Cell cellTest3;
	private Cell cellTest4;

	private Grid systemTest;

	Item organismTest;
	LowAnimal lowAnimal;

	/**
	 * sets up the tests.
	 * 
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {

		cellTest1 = new Cell(0, 0);
		cellTest2 = new Cell(0, 1);
		cellTest3 = new Cell(1, 0);
		cellTest4 = new Cell(1, 1);

		organismTest = new MiddleAnimal('F');
		lowAnimal = new LowAnimal('I');

		// first Ecosystem

		systemTest = new Ecosystem(2, 2);

		systemTest.add(organismTest, cellTest1);
		systemTest.add(organismTest, cellTest2);
		systemTest.add(organismTest, cellTest3);
		systemTest.add(null, cellTest4);

		// second ecosystem

		Grid systemTest2 = new Ecosystem(2, 2);

		systemTest2.add(organismTest, cellTest1);
		systemTest2.add(organismTest, cellTest2);
		systemTest2.add(organismTest, cellTest3);
		systemTest2.add(null, cellTest4);

		// third ecosystem
		Grid systemTest3 = new Ecosystem(2, 2);

		systemTest3.add(organismTest, cellTest1);
		systemTest3.add(organismTest, cellTest2);
		systemTest3.add(organismTest, cellTest3);
		systemTest3.add(organismTest, cellTest4);
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.MiddleAnimal#makeNewBaby()}.
	 */
	@Test
	public void testMakeNewBaby() {
		Item baby = ((MiddleAnimal) organismTest).makeNewBaby();
		assertEquals('F', baby.getSymbol());
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.MiddleAnimal#act(edu.ncsu.csc216.forest_system.model.Cell, edu.ncsu.csc216.forest_system.model.Grid)}
	 * .
	 */
	@Test
	public void testAct() {

		// checking if my animals are empty
		assertEquals(false, systemTest.isEmpty(cellTest1));
		assertEquals(false, systemTest.isEmpty(cellTest2));
		assertEquals(false, systemTest.isEmpty(cellTest3));
		assertEquals(true, systemTest.isEmpty(cellTest4));

		// enabling and acting
		systemTest.getItemAt(cellTest3).enable();
		systemTest.getItemAt(cellTest3).act(cellTest3, systemTest);

		// see if there is an animal in the spot
		assertEquals('F', systemTest.getItemAt(cellTest4).getSymbol());

		// remove a spot
		systemTest.remove(cellTest1);
		systemTest.add(lowAnimal, cellTest1);

		// see is the animal eats
		systemTest.getItemAt(cellTest2).enable();
		systemTest.getItemAt(cellTest2).act(cellTest2, systemTest);
		assertEquals(null, systemTest.getItemAt(cellTest2));

		// see if the animal moves
		systemTest.getItemAt(cellTest4).enable();
		systemTest.getItemAt(cellTest4).act(cellTest4, systemTest);
		assertEquals(null, systemTest.getItemAt(cellTest4));

		// see if animal dies
		systemTest.remove(cellTest1);
		systemTest.remove(cellTest2);
		systemTest.remove(cellTest3);
		systemTest.remove(cellTest4);
		systemTest.add(organismTest, cellTest1);
		systemTest.add(organismTest, cellTest2);
		systemTest.add(organismTest, cellTest4);
		systemTest.add(organismTest, cellTest3);

		for (int i = 0; i < 10; i++) {
			systemTest.getItemAt(cellTest3).enable();
			systemTest.getItemAt(cellTest3).act(cellTest3, systemTest);
		}
		assertEquals(false, systemTest.getItemAt(cellTest3).isAlive());
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.MiddleAnimal#pastBreedTime(int)}
	 * .
	 */
	@Test
	public void testPastBreedTime() {
		assertEquals(true, ((MiddleAnimal) organismTest).pastBreedTime(8));
		assertEquals(false, ((MiddleAnimal) organismTest).pastBreedTime(0));
	}

}
