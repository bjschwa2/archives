/**
 * 
 */
package edu.ncsu.csc216.forest_system.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * Test Method for HighAnimal.
 * 
 * @author bradley
 * 
 */
public class HighAnimalTest {

	private Cell cellTest1;
	private Cell cellTest2;
	private Cell cellTest3;
	private Cell cellTest4;

	private Grid systemTest;

	Item organismTest;
	LowAnimal lowAnimal;

	/**
	 * sets up the tests.
	 * 
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {

		cellTest1 = new Cell(0, 0);
		cellTest2 = new Cell(0, 1);
		cellTest3 = new Cell(1, 0);
		cellTest4 = new Cell(1, 1);

		organismTest = new HighAnimal('O');
		lowAnimal = new LowAnimal('I');

		// first Ecosystem

		systemTest = new Ecosystem(2, 2);

		systemTest.add(organismTest, cellTest1);
		systemTest.add(null, cellTest2);
		systemTest.add(null, cellTest3);
		systemTest.add(null, cellTest4);

		// second ecosystem

		Grid systemTest2 = new Ecosystem(2, 2);

		systemTest2.add(organismTest, cellTest1);
		systemTest2.add(organismTest, cellTest2);
		systemTest2.add(organismTest, cellTest3);
		systemTest2.add(null, cellTest4);

		// third ecosystem
		Grid systemTest3 = new Ecosystem(2, 2);

		systemTest3.add(organismTest, cellTest1);
		systemTest3.add(organismTest, cellTest2);
		systemTest3.add(organismTest, cellTest3);
		systemTest3.add(organismTest, cellTest4);
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.HighAnimal#makeNewBaby()}.
	 */
	@Test
	public void testMakeNewBaby() {
		Item baby = ((HighAnimal) organismTest).makeNewBaby();
		assertEquals('O', baby.getSymbol());
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.HighAnimal#act(edu.ncsu.csc216.forest_system.model.Cell, edu.ncsu.csc216.forest_system.model.Grid)}
	 * .
	 */
	@Test
	public void testAct() {
		// checking if my animals are empty
		assertEquals(false, systemTest.isEmpty(cellTest1));
		assertEquals(true, systemTest.isEmpty(cellTest2));
		assertEquals(true, systemTest.isEmpty(cellTest3));
		assertEquals(true, systemTest.isEmpty(cellTest4));

		// remove a spot

		systemTest.add(lowAnimal, cellTest2);

		// see is the animal eats
		systemTest.getItemAt(cellTest1).enable();
		systemTest.getItemAt(cellTest1).act(cellTest1, systemTest);
		assertEquals(null, systemTest.getItemAt(cellTest1));

		// enabling and acting

		systemTest.add(organismTest, cellTest3);
		systemTest.add(organismTest, cellTest4);
		systemTest.getItemAt(cellTest2).enable();
		systemTest.getItemAt(cellTest2).act(cellTest2, systemTest);

		// see if there is an animal in the spot
		assertEquals('O', systemTest.getItemAt(cellTest1).getSymbol());

		// see if the animal moves

		systemTest.remove(cellTest2);
		systemTest.getItemAt(cellTest1).enable();
		systemTest.getItemAt(cellTest1).act(cellTest1, systemTest);
		assertEquals(null, systemTest.getItemAt(cellTest1));

		// see if animal dies
		systemTest.remove(cellTest1);
		systemTest.remove(cellTest2);
		systemTest.remove(cellTest3);
		systemTest.remove(cellTest4);
		systemTest.add(organismTest, cellTest1);
		systemTest.add(organismTest, cellTest2);
		systemTest.add(organismTest, cellTest4);
		systemTest.add(organismTest, cellTest3);

		for (int i = 0; i < 10; i++) {
			systemTest.getItemAt(cellTest3).enable();
			systemTest.getItemAt(cellTest3).act(cellTest3, systemTest);
		}
		assertEquals(false, systemTest.getItemAt(cellTest3).isAlive());
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.HighAnimal#pastBreedTime(int)}
	 * .
	 */
	@Test
	public void testPastBreedTime() {
		assertEquals(true, ((HighAnimal) organismTest).pastBreedTime(16));
		assertEquals(false, ((HighAnimal) organismTest).pastBreedTime(0));
	}

}
