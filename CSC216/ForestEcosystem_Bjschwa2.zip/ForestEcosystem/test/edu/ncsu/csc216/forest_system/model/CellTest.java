/**
 * 
 */
package edu.ncsu.csc216.forest_system.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * Test method for Cell.
 * 
 * @author Bradley Schwarz
 */
public class CellTest {

	Cell cell;

	/**
	 * sets up the test.
	 * 
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {

		cell = new Cell(1, 1);
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.LowAnimal#cell()}.
	 */
	public void testCell() {

		// testCell is covered in the other classes that use cells
	}

	/**
	 * Test method for {@link edu.ncsu.csc216.forest_system.model.Cell#getRow()}
	 * .
	 */
	@Test
	public void testGetRow() {

		assertEquals(1, cell.getRow());

	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.Cell#getColumn()}.
	 */
	@Test
	public void testGetColumn() {

		assertEquals(1, cell.getCol());

	}

}
