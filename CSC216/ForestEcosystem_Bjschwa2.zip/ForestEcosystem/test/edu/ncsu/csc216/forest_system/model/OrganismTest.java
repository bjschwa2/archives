/**
 * 
 */
package edu.ncsu.csc216.forest_system.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * Test method for Organism.
 * 
 * @author Bradley Schwarz
 * 
 */
public class OrganismTest {

	private Cell cellTest1;
	private Cell cellTest2;
	Cell cellTest3;
	Cell cellTest4;

	private Grid systemTest;
	private Grid systemTest2;
	private Grid systemTest3;

	Item middleTest;

	Item lowTest;

	/**
	 * Sets up the tests.
	 * 
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {

		middleTest = new MiddleAnimal('F');
		lowTest = new LowAnimal('I');

		systemTest = new Ecosystem(2, 2);
		systemTest2 = new Ecosystem(2, 2);
		systemTest3 = new Ecosystem(2, 2);

		cellTest1 = new Cell(0, 0);
		cellTest2 = new Cell(0, 1);
		cellTest3 = new Cell(1, 0);
		cellTest4 = new Cell(1, 1);
		// grid for other
		systemTest.add(middleTest, cellTest2);
		systemTest.add(lowTest, cellTest1);

		// grid where nothing can't do anything
		systemTest2.add(lowTest, cellTest1);
		systemTest2.add(lowTest, cellTest2);
		systemTest2.add(lowTest, cellTest3);
		systemTest2.add(lowTest, cellTest4);
		// grid where stuff can act
		systemTest3.add(lowTest, cellTest1);

	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.Organism#isAlive()}.
	 */
	@Test
	public void testIsAlive() {

		assertEquals(middleTest.isAlive(), true);

		((Organism) middleTest).die();

		assertEquals(middleTest.isAlive(), false);
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.Organism#die()}.
	 */
	@Test
	public void testDie() {
		assertEquals(middleTest.isAlive(), true);

		((Organism) middleTest).die();

		assertEquals(middleTest.isAlive(), false);
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.Organism#canAct()}.
	 */
	@Test
	public void testCanAct() {

		((Organism) middleTest).enable();

		assertEquals(((Organism) middleTest).canAct(), true);

		((Organism) middleTest).disable();

		assertEquals(((Organism) middleTest).canAct(), false);
	}

	/**
	 * Test method forsystemTest = new Ecosystem(2, 2);
	 * {@link edu.ncsu.csc216.forest_system.model.Organism#enable()}.
	 */
	@Test
	public void testEnable() {
		((Organism) middleTest).enable();

		assertEquals(((Organism) middleTest).canAct(), true);

		((Organism) middleTest).disable();

		assertEquals(((Organism) middleTest).canAct(), false);
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.Organism#disable()}.
	 */
	@Test
	public void testDisable() {
		((Organism) middleTest).enable();

		assertEquals(((Organism) middleTest).canAct(), true);

		((Organism) middleTest).disable();

		assertEquals(((Organism) middleTest).canAct(), false);
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.Organism#incrementTimeSinceLastMeal()}
	 * .
	 */
	@Test
	public void testIncrementTimeSinceLastMeal() {
		((Organism) systemTest.getItemAt(cellTest2)).eat(cellTest2, systemTest);
		assertEquals(0,
				((Organism) systemTest.getItemAt(cellTest1))
						.getTimeSinceLastMeal());
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.Organism#incrementTimeSinceLastBreed()}
	 * .
	 */
	@Test
	public void testIncrementTimeSinceLastBreed() {
		((Organism) systemTest.getItemAt(cellTest2)).breed(cellTest2,
				systemTest);
		assertEquals(0,
				((Organism) systemTest.getItemAt(cellTest2))
						.getTimeSinceLastBreed());

	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.Organism#breed(edu.ncsu.csc216.forest_system.model.Cell, edu.ncsu.csc216.forest_system.model.Grid)}
	 * .
	 */
	@Test
	public void testBreed() {

		assertEquals(((Organism) systemTest2.getItemAt(cellTest1)).breed(
				cellTest1, systemTest2), false);
		assertEquals(((Organism) systemTest3.getItemAt(cellTest1)).breed(
				cellTest1, systemTest3), true);

	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.Organism#move(edu.ncsu.csc216.forest_system.model.Cell, edu.ncsu.csc216.forest_system.model.Grid)}
	 * .
	 */
	@Test
	public void testMove() {

		systemTest2.remove(cellTest2);
		((Organism) systemTest2.getItemAt(cellTest1)).move(cellTest1,
				systemTest2);
		assertEquals('I', systemTest2.getItemAt(cellTest2).getSymbol());

	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.Organism#eat(edu.ncsu.csc216.forest_system.model.Cell, edu.ncsu.csc216.forest_system.model.Grid)}
	 * .
	 */
	@Test
	public void testEat() {
		assertEquals(((Organism) systemTest2.getItemAt(cellTest1)).eat(
				cellTest1, systemTest2), false);
		systemTest3.add(middleTest, cellTest2);
		assertEquals(((Organism) systemTest3.getItemAt(cellTest2)).eat(
				cellTest2, systemTest3), true);
	}

}
