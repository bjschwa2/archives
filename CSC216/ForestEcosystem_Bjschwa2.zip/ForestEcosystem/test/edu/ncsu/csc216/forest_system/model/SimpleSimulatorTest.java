/**
 * 
 */
package edu.ncsu.csc216.forest_system.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * Test Class for SimpleSimulator
 * 
 * @author Bradley Schwarz
 * 
 */
public class SimpleSimulatorTest {

	SimpleSimulator fileInput;
	String[] names;
	SimpleSimulator test;
	SimpleSimulator badTest;
	SimpleSimulator testSimulator;

	Cell cellTest1;
	Cell cellTest2;
	Cell cellTest3;
	Cell cellTest4;

	Grid systemTest;
	Grid systemTest2;
	Grid systemTest3;

	Item middleTest;

	/**
	 * Test method for SimpleSimulator
	 * 
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {

		middleTest = new MiddleAnimal('F');

		testSimulator = new SimpleSimulator("testSimulator.txt");

	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.LowAnimal#SimpleSimulator()}.
	 */
	@Test
	public void testSimpleSimulator() {
		fail();

	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.SimpleSimulator#step()}.
	 */
	@Test
	public void testStep() {

		testSimulator.step();

		assertEquals(testSimulator.snapshot()[0][0], null);

	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.SimpleSimulator#displayItemNames()}
	 * .
	 */
	@Test
	public void testDisplayItemNames() {

		fail();

	}

}
