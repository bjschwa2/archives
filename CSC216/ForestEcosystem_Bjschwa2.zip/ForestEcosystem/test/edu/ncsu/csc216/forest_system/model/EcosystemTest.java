/**
 * 
 */
package edu.ncsu.csc216.forest_system.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * Test method for Ecosystem.
 * 
 * @author Bradley Schwarz
 * 
 */
public class EcosystemTest {
	private Cell cellTest1;
	private Cell cellTest2;
	private Cell cellTest3;
	private Cell celltest4;
	private Cell cellTest5;

	private Cell cellTest9;
	private Grid systemTest;
	private Grid systemTest2;
	Item organismTest;
	Item organismTest1;
	Item organismTest2;
	Item organismTest3;
	Item organismTest4;
	Item sample;

	Item[][] itemArray;

	/**
	 * Sets up the test cases.
	 * 
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		systemTest = new Ecosystem(3, 3);
		systemTest2 = new Ecosystem(3, 3);
		cellTest1 = new Cell(0, 0);
		cellTest2 = new Cell(0, 1);
		cellTest3 = new Cell(0, 2);
		celltest4 = new Cell(1, 0);
		cellTest5 = new Cell(1, 1);

		cellTest9 = new Cell(2, 2);
		organismTest = new MiddleAnimal('F');
		organismTest1 = new MiddleAnimal('F');
		systemTest.add(organismTest, cellTest2);
		systemTest.add(null, cellTest1);
		systemTest.add(null, cellTest3);
		systemTest.add(null, celltest4);
		systemTest.add(null, cellTest5);

		systemTest.add(null, cellTest9);
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.Ecosystem#isEmpty(edu.ncsu.csc216.forest_system.model.Cell)}
	 * .
	 */
	@Test
	public void testIsEmpty() {
		assertEquals(true, systemTest.isEmpty(cellTest1));
		systemTest.add(organismTest, cellTest1);
		assertEquals(false, systemTest.isEmpty(cellTest2));
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.Ecosystem#getItemAt(edu.ncsu.csc216.forest_system.model.Cell)}
	 * .
	 */
	@Test
	public void testGetItemAt() {

		sample = systemTest.getItemAt(cellTest2);

		boolean notEmpty = false;
		if (sample != null) {
			notEmpty = true;
		}
		assertEquals(true, notEmpty);
		assertEquals('F', systemTest.getItemAt(cellTest2).getSymbol());

	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.Ecosystem#remove(edu.ncsu.csc216.forest_system.model.Cell)}
	 * .
	 */
	@Test
	public void testRemove() {
		systemTest.add(organismTest, cellTest1);
		assertEquals('F', systemTest.getItemAt(cellTest1).getSymbol());
		systemTest.remove(cellTest1);
		sample = systemTest.getItemAt(cellTest1);
		boolean notEmpty = false;
		if (sample == null) {
			notEmpty = true;
		}
		assertEquals(true, notEmpty);
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.Ecosystem#add(edu.ncsu.csc216.forest_system.model.Item, edu.ncsu.csc216.forest_system.model.Cell)}
	 * .
	 */
	@Test
	public void testAdd() {
		sample = systemTest.getItemAt(cellTest1);
		boolean notEmpty = false;
		if (sample == null) {
			notEmpty = true;
		}
		assertEquals(true, notEmpty);
		systemTest.add(organismTest, cellTest1);
		sample = systemTest.getItemAt(cellTest1);
		assertEquals('F', sample.getSymbol());
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.Ecosystem#findFirstEmptyNeighbor(edu.ncsu.csc216.forest_system.model.Cell, int)}
	 * .
	 */
	@Test
	public void testFindFirstEmptyNeighbor() {
		Cell cellTest = systemTest.findFirstEmptyNeighbor(cellTest5, 0);
		assertEquals(0, cellTest.getCol());
		cellTest = systemTest.findFirstEmptyNeighbor(cellTest5, 2);
		assertEquals(2, cellTest.getCol());
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.Ecosystem#dueNorth(edu.ncsu.csc216.forest_system.model.Cell)}
	 * .
	 */
	@Test
	public void testDueNorth() {
		assertEquals(0, systemTest.dueNorth(celltest4).getRow());
		assertEquals(2, systemTest.dueNorth(cellTest1).getRow());
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.Ecosystem#dueSouth(edu.ncsu.csc216.forest_system.model.Cell)}
	 * .
	 */
	@Test
	public void testDueSouth() {
		assertEquals(2, systemTest.dueSouth(celltest4).getRow());
		assertEquals(0, systemTest.dueSouth(cellTest9).getRow());
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.Ecosystem#dueWest(edu.ncsu.csc216.forest_system.model.Cell)}
	 * .
	 */
	@Test
	public void testDueWest() {
		assertEquals(2, systemTest.dueWest(celltest4).getCol());
		assertEquals(1, systemTest.dueWest(cellTest3).getCol());
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.Ecosystem#dueEast(edu.ncsu.csc216.forest_system.model.Cell)}
	 * .
	 */
	@Test
	public void testDueEast() {
		assertEquals(1, systemTest.dueEast(celltest4).getCol());
		assertEquals(0, systemTest.dueEast(cellTest3).getCol());
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.Ecosystem#snapshot()}.
	 */
	@Test
	public void testSnapshot() {

		systemTest2.add(organismTest, cellTest1);

		Item[][] actual = systemTest2.snapshot();
		Item getItem = actual[0][1];

		assertEquals(null, getItem);
	}

}
