/**
 * 
 */
package edu.ncsu.csc216.forest_system.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/**
 * Test Method for LowAnimal.
 * 
 * @author bradley
 * 
 */
public class LowAnimalTest {

	private Cell cellTest1;
	private Cell cellTest2;
	private Cell cellTest3;
	private Cell cellTest4;

	private Grid systemTest;

	Item organismTest;

	/**
	 * sets up the tests.
	 * 
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {

		cellTest1 = new Cell(0, 0);
		cellTest2 = new Cell(0, 1);
		cellTest3 = new Cell(1, 0);
		cellTest4 = new Cell(1, 1);

		organismTest = new LowAnimal('I');

		// first Ecosystem

		systemTest = new Ecosystem(2, 2);

		systemTest.add(organismTest, cellTest1);
		systemTest.add(organismTest, cellTest2);
		systemTest.add(organismTest, cellTest3);
		systemTest.add(null, cellTest4);

		// second ecosystem

		Grid systemTest2 = new Ecosystem(2, 2);

		systemTest2.add(organismTest, cellTest1);
		systemTest2.add(organismTest, cellTest2);
		systemTest2.add(organismTest, cellTest3);
		systemTest2.add(null, cellTest4);

		// third ecosystem
		Grid systemTest3 = new Ecosystem(2, 2);

		systemTest3.add(organismTest, cellTest1);
		systemTest3.add(organismTest, cellTest2);
		systemTest3.add(organismTest, cellTest3);
		systemTest3.add(organismTest, cellTest4);

	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.LowAnimal#makeNewBaby()}.
	 */
	@Test
	public void testMakeNewBaby() {

		Item baby = ((LowAnimal) organismTest).makeNewBaby();
		assertEquals('I', baby.getSymbol());
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.LowAnimal#act(edu.ncsu.csc216.forest_system.model.Cell, edu.ncsu.csc216.forest_system.model.Grid)}
	 * .
	 */
	@Test
	public void testAct() {

		// checking if my animals are empty
		assertEquals(false, systemTest.isEmpty(cellTest1));
		assertEquals(false, systemTest.isEmpty(cellTest2));
		assertEquals(false, systemTest.isEmpty(cellTest3));
		assertEquals(true, systemTest.isEmpty(cellTest4));

		// enabling and acting
		systemTest.getItemAt(cellTest3).enable();
		systemTest.getItemAt(cellTest3).act(cellTest3, systemTest);

		// see if there is an animal in the spot
		assertEquals('I', systemTest.getItemAt(cellTest4).getSymbol());

		// remove a spot
		systemTest.remove(cellTest1);

		// see if the animal moves
		systemTest.getItemAt(cellTest4).enable();
		systemTest.getItemAt(cellTest4).act(cellTest4, systemTest);
		assertEquals(null, systemTest.getItemAt(cellTest4));

		// test it animal dies
		systemTest.add(organismTest, cellTest4);
		for (int i = 0; i < 11; i++) {
			systemTest.getItemAt(cellTest4).enable();
			systemTest.getItemAt(cellTest4).act(cellTest4, systemTest);
		}

		// assertEquals(null, systemTest.getItemAt(cellTest4));
	}

	/**
	 * Test method for
	 * {@link edu.ncsu.csc216.forest_system.model.LowAnimal#pastBreedTime(int)}.
	 */
	@Test
	public void testPastBreedTime() {
		assertEquals(true, ((LowAnimal) organismTest).pastBreedTime(3));
		assertEquals(false, ((LowAnimal) organismTest).pastBreedTime(0));
	}

}
