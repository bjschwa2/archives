/**
 * 
 */
package edu.ncsu.csc216.movie_inventory;

import java.util.Scanner;

/**
 * Front User interaction class for the MovieInventory class
 * 
 * @author bradley Schwarz
 * 
 */
public class MovieInventoryUI {

	private static final int LIST_LENGTH = 10;

	private Scanner console;

	/**
	 * the inventory object which can call other classes methods
	 * 
	 * @param args
	 */
	private MovieInventory inventory;

	/**
	 * Constructs a MovieInventoryUI object that contains a MovieInventory and a
	 * Scanner for reading console input.
	 */
	public MovieInventoryUI() {
		inventory = new MovieInventory();
		console = new Scanner(System.in);
	}

	/**
	 * Controls the looping of the user interface.
	 */
	public void userInterface() {
		while (true) {
			boolean test = false;
			int selectionInt = -1;
			while (!test) {
				System.out.println("MovieInventory Menu:");
				System.out.println("1. List Movies");
				System.out.println("2. Add Movie");
				System.out.println("3. Remove Movie by Title");
				System.out.println("4. Quit");

				System.out.println("Entry?");
				String selection = console.nextLine().substring(0, 1);
				boolean test2 = true;
				try {
					Integer.parseInt(selection);
				} catch (NumberFormatException e) {
					System.out.println("Invalid command.");
					test2 = false;
				}
				if (test2) {
					selectionInt = Integer.parseInt(selection);
					test = true;

				}

			}

			if (selectionInt == 1 || selectionInt == 2 || selectionInt == 3
					|| selectionInt == 4) {
				if (selectionInt == 1) {
					listMovies();
				} else if (selectionInt == 2) {
					promptForMovie();
				} else if (selectionInt == 3) {
					removeMovie();
				} else if (selectionInt == 4) {
					System.exit(0);
				}
			} else {
				System.out.println("Invalid Command");
			}
		}

	}

	/**
	 * lists the movies stored in the movies array
	 */
	public void listMovies() {
		System.out.println("Movie Inventory:");
		String[] listOfMovies = inventory.getList();

		for (int i = 0; i < LIST_LENGTH; i++) {
			System.out.println(listOfMovies[i]);
		}

	}

	/**
	 * removes the users specified movie
	 */
	public void removeMovie() {
		System.out.println("Title to Remove?");
		String movieTitle = console.nextLine();
		if (inventory.movieToRemove(movieTitle)) {
			System.out.println("Movie removed from collection.");
		} else {
			System.out.println("Movie cannot be removed from the collection.");
		}

	}

	/**
	 * UI functionality for adding a Movie.
	 */
	public void promptForMovie() {
		System.out.println("\nTitle? ");
		String title = console.nextLine();

		System.out.println("Release Year? ");
		while (!console.hasNextInt()) {
			System.out.println("Invalid release year.");
			console.nextLine(); // throw away rest of line
		}
		int releaseYear = console.nextInt();
		console.nextLine();

		System.out.println("Genre? ");
		String genre = console.nextLine();

		System.out.println("Rating? ");
		String rating = console.nextLine();

		try {
			Movie m = new Movie(title, releaseYear, genre, rating);
			if (inventory.addMovie(m)) {
				System.out.println("Movie added to collection.");
			} else {
				System.out.println("Movie cannot be added to the collection.");
			}
		} catch (IllegalArgumentException e) {
			System.out.println("Invalid release year.");
		}
	}

	/**
	 * Starts the program.
	 * 
	 * @param args
	 *            command line args
	 */
	public static void main(String[] args) {
		MovieInventoryUI ui = new MovieInventoryUI();
		ui.userInterface();
	}

}
