/**
 * 
 */
package edu.ncsu.csc216.movie_inventory;

/**
 * Sorting or inventory class for the Movie Class
 * 
 * @author Bradley Schwarz
 * 
 */
public class MovieInventory {
	/**
	 * The total inventory size
	 */
	public static final int INVENTORY_SIZE = 10;

	/**
	 * the movies array
	 */
	private Movie[] movies;

	/**
	 * the movies array converted to a string
	 */
	private String[] movieString;

	/**
	 * Instance variables for the movieInventory class
	 */
	public MovieInventory() {
		movies = new Movie[INVENTORY_SIZE];
		movieString = new String[INVENTORY_SIZE];
	}

	/**
	 * Returns true if the Movie can be added to the inventory. If the Movie is
	 * a duplicate or if there is no more space, the method returns false.
	 * 
	 * @param m
	 *            Movie to add to the inventory
	 * @return true if the Movie can be added to the inventory
	 */
	public boolean addMovie(Movie m) {
		// Check for duplicate movies
		for (int i = 0; i < INVENTORY_SIZE; i++) {
			if (movies[i] != null && movies[i].equals(m)) {
				return false; // movie already exists
			}
		}
		boolean added = false; // flag
		for (int i = 0; i < INVENTORY_SIZE; i++) {
			if (movies[i] == null) { // the movie slot is empty
				movies[i] = m;
				added = true;
				break; // if we added, break out of the loop
			}
		}
		return added; // return the flag
	}

	/**
	 * sends the non null movies to become strings
	 * 
	 */
	public void makeList() {
		for (int i = 0; i < movieString.length; i++) {
			if (movies[i] == null) {
				movieString[i] = "Empty";
			} else {
				movieString[i] = movies[i].toString();
			}
		}

	}

	/**
	 * becomes a string in the correct formatting
	 * 
	 * @return newString the new string containing the movie
	 */
	public String[] getList() {
		makeList();
		String[] newString = new String[INVENTORY_SIZE];
		for (int i = 0; i < movieString.length; i++) {
			newString[i] = (i + 1) + "." + movieString[i];
		}
		return newString;
	}

	/**
	 * Determines if the users movie is not null then removes the movie.
	 * 
	 * @param movieTitle the users movie title
	 * @return remove If the movie was removed
	 */
	public boolean movieToRemove(String movieTitle){
		boolean remove = false;
		for (int i = 0; i < movies.length; i++) {
			if (movies[i] != null)
				if (movies[i].getTitle().equals(movieTitle)) {
					movies[i] = null;
					remove = true;

				}
		}
		return remove;

	}

}
