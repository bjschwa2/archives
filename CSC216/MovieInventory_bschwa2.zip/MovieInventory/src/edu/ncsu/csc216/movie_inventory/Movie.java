/**
 * 
 */
package edu.ncsu.csc216.movie_inventory;

/**
 * The Movie Class controls the Movie object
 * 
 * @author bradley Schwarz
 * 
 */
public class Movie {

	private static final int MIN_RELEASE_YEAR = 1880;
	private String title;
	private int releaseYear;
	private String genre;
	private String rating;

	/**
	 * Constructs a Movie object
	 * 
	 * @param title
	 *            Movie's title
	 * @param releaseYear
	 *            Movie's release year
	 * @param genre
	 *            Movie's genre
	 * @param rating
	 *            Movie's rating
	 */
	public Movie(String title, int releaseYear, String genre, String rating) {
		super();
		if (releaseYear < MIN_RELEASE_YEAR) {
			throw new IllegalArgumentException();
		}
		this.title = title;
		this.releaseYear = releaseYear;
		this.genre = genre;
		this.rating = rating;
	}

	/**
	 * Getter method for title
	 * 
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Getter method for release year
	 * 
	 * @return the releaseYear
	 */
	public int getReleaseYear() {
		return releaseYear;
	}

	/**
	 * Getter method for genre
	 * 
	 * @return the genre
	 */
	public String getGenre() {
		return genre;
	}

	/**
	 * Getter method for genre
	 * 
	 * @return the rating
	 */
	public String getRating() {
		return rating;
	}

	/**
	 * returns a string of the movie components
	 * 
	 * @return the string of components
	 */
	public String toString() {
		return "Movie [title=" + title + ", releaseYear=" + releaseYear
				+ ", genre=" + genre + ", rating=" + rating + "]";
	}

	/**
	 * impliments the hash code
	 * 
	 * @return result returns the hash result
	 */
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((genre == null) ? 0 : genre.hashCode());
		result = prime * result + ((rating == null) ? 0 : rating.hashCode());
		result = prime * result + releaseYear;
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		return result;
	}

	/**
	 * Determines if the movie is a specific genre rating etc.
	 * 
	 * @param obj the object
	 * @return returns false if not and true if it is.
	 */
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Movie other = (Movie) obj;
		if (genre == null) {
			if (other.genre != null)
				return false;
		} else if (!genre.equals(other.genre))
			return false;
		if (rating == null) {
			if (other.rating != null)
				return false;
		} else if (!rating.equals(other.rating))
			return false;
		if (releaseYear != other.releaseYear)
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		return true;
	}
}
